package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.CourseInfo;
import com.example.demo.repo.CourseInfoRepository;

@Service
public class CourseInfoServiceImpl implements CourseInfoService {

    @Autowired
    private CourseInfoRepository courseRepo;

    @Override
    public CourseInfo createCourse(CourseInfo course) {
        return courseRepo.save(course);
    }

    @Override
    public List<CourseInfo> getAllCourses() {
        return courseRepo.findAll();
    }

    @Override
    public CourseInfo getCourseById(int id) {
        return courseRepo.findById(id).orElseThrow(() -> new RuntimeException("Course not found with ID: " + id));
    }

    @Override
    public CourseInfo updateCourse(int id, CourseInfo updatedCourse) {
        CourseInfo course = courseRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found with ID: " + id));
        course.setTitle(updatedCourse.getTitle());
        course.setCprice(updatedCourse.getCprice());
        course.setDuration(updatedCourse.getDuration());
        return courseRepo.save(course);
    }

    @Override
    public void deleteCourse(int id) {
        if (!courseRepo.existsById(id)) {
            throw new RuntimeException("Course not found with ID: " + id);
        }
        courseRepo.deleteById(id);
    }
}
