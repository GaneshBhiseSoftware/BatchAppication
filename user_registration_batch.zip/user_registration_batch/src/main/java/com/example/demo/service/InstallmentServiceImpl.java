package com.example.demo.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.CourseInfo;
import com.example.demo.entity.Installment;
import com.example.demo.entity.User;
import com.example.demo.repo.CourseInfoRepository;
import com.example.demo.repo.InstallmentRepository;
import com.example.demo.repo.UserRepository;

@Service
public class InstallmentServiceImpl implements InstallmentService {

    @Autowired
    private InstallmentRepository installmentRepo;

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private CourseInfoRepository courseRepo;

    @Override
    public void createInstallments(int userId, int courseId, int type) {
        User user = userRepo.findById(userId).orElseThrow();
        CourseInfo course = courseRepo.findById(courseId).orElseThrow();

        List<Installment> installments = new ArrayList<>();

        if (type == 1) { // One-Time
            LocalDate due = LocalDate.of(2025, 8, 1);
            installments.add(new Installment(user, course, 23000, due, false, 0));
        } else if (type == 2) {
            installments.add(new Installment(user, course, 12500, LocalDate.of(2025, 8, 1), false, 0));
            installments.add(new Installment(user, course, 12500, LocalDate.of(2025, 9, 1), false, 0));
        } else if (type == 3) {
            installments.add(new Installment(user, course, 10000, LocalDate.of(2025, 8, 1), false, 0));
            installments.add(new Installment(user, course, 10000, LocalDate.of(2025, 9, 1), false, 0));
            installments.add(new Installment(user, course, 5000, LocalDate.of(2025, 10, 1), false, 0));
        }

        installmentRepo.saveAll(installments);
    }

    @Override
    public Installment payInstallment(int id, LocalDate paidDate) {
        Installment inst = installmentRepo.findById(id).orElseThrow();
        inst.setPaidDate(paidDate);
        inst.setPaid(true);

        // Fine logic
        if (paidDate.isAfter(inst.getDueDate())) {
            inst.setFine(1000);
        } else {
            inst.setFine(0);
        }

        return installmentRepo.save(inst);
    }

    @Override
    public List<Installment> getInstallmentsByUser(int userId) {
        return installmentRepo.findByUser_Id(userId);
    }
}
