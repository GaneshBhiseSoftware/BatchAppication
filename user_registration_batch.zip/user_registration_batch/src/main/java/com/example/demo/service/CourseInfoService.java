package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.CourseInfo;

public interface CourseInfoService {
    CourseInfo createCourse(CourseInfo course);
    List<CourseInfo> getAllCourses();
    CourseInfo getCourseById(int id);
    CourseInfo updateCourse(int id, CourseInfo course);
    void deleteCourse(int id);
}
