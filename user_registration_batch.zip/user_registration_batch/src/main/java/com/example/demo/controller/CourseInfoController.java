package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.CourseInfo;
import com.example.demo.service.CourseInfoService;

@RestController
@CrossOrigin(origins = "https://lovelyavsoft.tiiny.site/index.html")
//@CrossOrigin(origins = "*")
@RequestMapping("/api/courses")
public class CourseInfoController {

    @Autowired
    private CourseInfoService courseService;

    @PostMapping("/create")
    public ResponseEntity<CourseInfo> createCourse(@RequestBody CourseInfo course) {
        return ResponseEntity.ok(courseService.createCourse(course));
    }

    @GetMapping("/all")
    public ResponseEntity<List<CourseInfo>> getAllCourses() {
        return ResponseEntity.ok(courseService.getAllCourses());
    }

    @GetMapping("/{id}")
    public ResponseEntity<CourseInfo> getCourseById(@PathVariable int id) {
        return ResponseEntity.ok(courseService.getCourseById(id));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<CourseInfo> updateCourse(@PathVariable int id, @RequestBody CourseInfo updatedCourse) {
        return ResponseEntity.ok(courseService.updateCourse(id, updatedCourse));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteCourse(@PathVariable int id) {
        courseService.deleteCourse(id);
        return ResponseEntity.ok("Course deleted successfully.");
    }
}
