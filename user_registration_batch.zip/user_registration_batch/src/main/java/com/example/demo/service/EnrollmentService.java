package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.EnrollmentRequest;

public interface EnrollmentService {
	EnrollmentRequest requestEnrollment(int userId, int batchId);

	List<EnrollmentRequest> getPendingRequests();

	EnrollmentRequest approveRequest(int requestId);

	EnrollmentRequest rejectRequest(int requestId);

	List<EnrollmentRequest> getUserEnrollments(int userId);

	EnrollmentRequest getApprovedEnrollment(int userId);
}
//package com.example.demo.service;
//
//import java.util.List;
//
//import com.example.demo.entity.EnrollmentRequest;
//
//public interface EnrollmentService {
//    EnrollmentRequest requestEnrollment(int userId, int batchId);
//    List<EnrollmentRequest> getPendingRequests();
//    EnrollmentRequest approveRequest(int requestId);
//    EnrollmentRequest rejectRequest(int requestId);
//    List<EnrollmentRequest> getUserEnrollments(int userId);
//    EnrollmentRequest getApprovedEnrollment(int userId); 
//}