package com.example.demo.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Installment;
import com.example.demo.service.InstallmentService;

@RestController
@CrossOrigin(origins = "https://lovelyavsoft.tiiny.site/index.html")
//@CrossOrigin(origins = "*") 
@RequestMapping("/api/installments")
public class InstallmentController {

    @Autowired
    private InstallmentService installmentService;

    @PostMapping("/create")
    public ResponseEntity<String> create(@RequestParam int userId, @RequestParam int courseId, @RequestParam int type) {
        installmentService.createInstallments(userId, courseId, type);
        return ResponseEntity.ok("Installment plan created.");
    }

    @PutMapping("/pay/{id}")
    public ResponseEntity<Installment> pay(@PathVariable int id, @RequestParam String paidDate) {
        return ResponseEntity.ok(installmentService.payInstallment(id, LocalDate.parse(paidDate)));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Installment>> getAll(@PathVariable int userId) {
        return ResponseEntity.ok(installmentService.getInstallmentsByUser(userId));
    }
}
