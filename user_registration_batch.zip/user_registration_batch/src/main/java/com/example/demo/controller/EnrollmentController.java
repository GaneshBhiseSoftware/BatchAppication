package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.EnrollmentRequest;
import com.example.demo.service.EnrollmentService;

@RestController
@RequestMapping("/api/enrollments")
@CrossOrigin(origins = "https://lovelyavsoft.tiiny.site/index.html")
//@CrossOrigin(origins = "*") 
public class EnrollmentController {
	  @Autowired
	    private EnrollmentService enrollmentService;

	    @PostMapping("/request")
	    public ResponseEntity<EnrollmentRequest> enroll(
	            @RequestParam int userId,
	            @RequestParam int batchId) {
	        return ResponseEntity.ok(enrollmentService.requestEnrollment(userId, batchId));
	    }

	    @GetMapping("/pending")
	    public ResponseEntity<List<EnrollmentRequest>> getPendingRequests() {
	        return ResponseEntity.ok(enrollmentService.getPendingRequests());
	    }

	    @PutMapping("/approve/{id}")
	    public ResponseEntity<EnrollmentRequest> approveRequest(@PathVariable int id) {
	        return ResponseEntity.ok(enrollmentService.approveRequest(id));
	    }

	    @PutMapping("/reject/{id}")
	    public ResponseEntity<EnrollmentRequest> rejectRequest(@PathVariable int id) {
	        return ResponseEntity.ok(enrollmentService.rejectRequest(id));
	    }

	    @GetMapping("/user/{userId}")
	    public ResponseEntity<List<EnrollmentRequest>> getUserEnrollments(@PathVariable int userId) {
	        return ResponseEntity.ok(enrollmentService.getUserEnrollments(userId));
	    }

	    @GetMapping("/enrolled/{userId}")
	    public ResponseEntity<EnrollmentRequest> getApprovedEnrollment(@PathVariable int userId) {
	        return ResponseEntity.ok(enrollmentService.getApprovedEnrollment(userId));
	    }
	}
	