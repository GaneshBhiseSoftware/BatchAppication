package com.example.demo.entity;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class EnrollmentRequest {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@ManyToOne
	private User user;

	@ManyToOne

	@JsonIgnoreProperties("enrollments")
	private Batch batch;

	private String status; // PENDING / APPROVED / REJECTED
	private LocalDate requestDate;

	public EnrollmentRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EnrollmentRequest(int id, User user, Batch batch, String status, LocalDate requestDate) {
		super();
		this.id = id;
		this.user = user;
		this.batch = batch;
		this.status = status;
		this.requestDate = requestDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Batch getBatch() {
		return batch;
	}

	public void setBatch(Batch batch) {
		this.batch = batch;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDate getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(LocalDate requestDate) {
		this.requestDate = requestDate;
	}

}
