package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Batch;
import com.example.demo.entity.CourseInfo;
import com.example.demo.repo.BatchRepository;
import com.example.demo.repo.CourseInfoRepository;

@Service
public class BatchServiceImpl implements BatchService {

    @Autowired
    private BatchRepository batchRepo;

    @Autowired
    private CourseInfoRepository courseRepo;

    @Override
    public Batch createBatch(Batch batch) {
        return batchRepo.save(batch);
    }

    @Override
    public List<Batch> getBatchesByCourse(int courseId) {
        return batchRepo.findByCourseInfoCid(courseId);
    }

    @Override
    public List<Batch> getAllBatches() {
        return batchRepo.findAll();
    }

    @Override
    public Batch getBatchById(int id) {
        return batchRepo.findById(id).orElseThrow(() -> new RuntimeException("Batch not found"));
    }

    @Override
    public Batch updateBatch(int id, Batch updatedBatch) {
        Batch batch = batchRepo.findById(id).orElseThrow(() -> new RuntimeException("Batch not found"));

        batch.setTitle(updatedBatch.getTitle());

        CourseInfo course = courseRepo.findById(updatedBatch.getCourseInfo().getCid())
                .orElseThrow(() -> new RuntimeException("Course not found"));
        batch.setCourseInfo(course);

        batch.setCreatedBy(updatedBatch.getCreatedBy());

        return batchRepo.save(batch);
    }

    @Override
    public void deleteBatch(int id) {
        batchRepo.deleteById(id);
    }
}
