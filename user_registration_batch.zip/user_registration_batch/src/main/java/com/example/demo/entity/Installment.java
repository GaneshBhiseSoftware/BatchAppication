package com.example.demo.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Installment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@ManyToOne
	private User user;

	@ManyToOne
	private CourseInfo course;

	@Override
	public String toString() {
		return "Installment [id=" + id + ", user=" + user + ", course=" + course + ", amount=" + amount + ", dueDate="
				+ dueDate + ", paidDate=" + paidDate + ", fine=" + fine + ", paid=" + paid + "]";
	}

	public Installment(User user, CourseInfo course, int amount, LocalDate dueDate, boolean paid, int fine) {
	    this.user = user;
	    this.course = course;
	    this.amount = amount;
	    this.dueDate = dueDate;
	    this.paid = paid;
	    this.fine = fine;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public CourseInfo getCourse() {
		return course;
	}

	public void setCourse(CourseInfo course) {
		this.course = course;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public LocalDate getPaidDate() {
		return paidDate;
	}

	public void setPaidDate(LocalDate paidDate) {
		this.paidDate = paidDate;
	}

	public int getFine() {
		return fine;
	}

	public void setFine(int fine) {
		this.fine = fine;
	}

	public boolean isPaid() {
		return paid;
	}

	public void setPaid(boolean paid) {
		this.paid = paid;
	}

	public Installment() {
		super();
		// TODO Auto-generated constructor stub
	}

	private int amount;
	private LocalDate dueDate;
	private LocalDate paidDate;
	private int fine;
	private boolean paid;

}
