package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.EnrollmentRequest;

@Repository
public interface EnrollmentRequestRepository extends JpaRepository<EnrollmentRequest, Integer> {
	List<EnrollmentRequest> findByStatus(String status);

	List<EnrollmentRequest> findByUser_Id(int userId);

	EnrollmentRequest findByUserIdAndStatus(int userId, String status);

}
