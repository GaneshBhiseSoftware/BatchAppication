package com.example.demo.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.EnrollmentRequest;
import com.example.demo.repo.BatchRepository;
import com.example.demo.repo.EnrollmentRequestRepository;
import com.example.demo.repo.UserRepository;

@Service
public class EnrollmentServiceImpl implements EnrollmentService {

	@Autowired
	private EnrollmentRequestRepository enrollRepo;

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private BatchRepository batchRepo;

	@Override
	public EnrollmentRequest requestEnrollment(int userId, int batchId) {
		EnrollmentRequest request = new EnrollmentRequest();
		request.setUser(userRepo.findById(userId).orElseThrow());
		request.setBatch(batchRepo.findById(batchId).orElseThrow());
		request.setStatus("PENDING");
		request.setRequestDate(LocalDate.now());

		return enrollRepo.save(request);
	}

	@Override
	public List<EnrollmentRequest> getPendingRequests() {
		return enrollRepo.findByStatus("PENDING");
	}

	@Override
	public EnrollmentRequest approveRequest(int requestId) {
		EnrollmentRequest req = enrollRepo.findById(requestId).orElseThrow();
		req.setStatus("APPROVED");
		return enrollRepo.save(req);
	}

	@Override
	public List<EnrollmentRequest> getUserEnrollments(int userId) {
		return enrollRepo.findByUser_Id(userId);
	}

	@Override
	public EnrollmentRequest rejectRequest(int requestId) {
		EnrollmentRequest request = enrollRepo.findById(requestId)
				.orElseThrow(() -> new RuntimeException("Request not found"));

		request.setStatus("REJECTED");
		return enrollRepo.save(request);
	}

	@Override
	public EnrollmentRequest getApprovedEnrollment(int userId) {
	    return enrollRepo.findByUserIdAndStatus(userId, "APPROVED");
	}

}
