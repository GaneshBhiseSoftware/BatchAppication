package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.repo.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepo;

	@Override
	public User register(User user) {
		return userRepo.save(user);
	}

	@Override
	public User login(String email, String password) {
		return userRepo.findByEmail(email).filter(u -> u.getPassword().equals(password)).orElse(null);
	}

	@Override
	public User getById(int id) {
		return userRepo.findById(id).orElse(null);
	}

	@Override
	public List<User> getAllUsers() {
		return userRepo.findAll();
	}

	@Override
	public User updateUser(int id, User updatedUser) {
		User user = userRepo.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
		user.setFullname(updatedUser.getFullname());
		user.setEmail(updatedUser.getEmail());
		user.setPassword(updatedUser.getPassword());
		user.setRole(updatedUser.getRole());
		user.setUserMobile(updatedUser.getUserMobile());
		user.setParentMobile(updatedUser.getParentMobile());
		user.setImageUrl(updatedUser.getImageUrl());
		return userRepo.save(user);
	}

	@Override
	public void deleteUser(int id) {
		userRepo.deleteById(id);
	}

}
