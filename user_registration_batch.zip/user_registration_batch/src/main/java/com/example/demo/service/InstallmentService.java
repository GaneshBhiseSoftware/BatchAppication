package com.example.demo.service;

import java.time.LocalDate;
import java.util.List;

import com.example.demo.entity.Installment;

public interface InstallmentService {
    void createInstallments(int userId, int courseId, int type); // 1 = one-time, 2 = two, 3 = three
    Installment payInstallment(int installmentId, LocalDate paidDate);
    List<Installment> getInstallmentsByUser(int userId);
}
