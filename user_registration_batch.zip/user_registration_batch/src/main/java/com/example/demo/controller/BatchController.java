package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Batch;
import com.example.demo.service.BatchService;

@RestController
@CrossOrigin(origins = "https://lovelyavsoft.tiiny.site/index.html")
@RequestMapping("/api/batches")
public class BatchController {

	@Autowired
	private BatchService batchService;

	@PostMapping("/create")
	public ResponseEntity<Batch> createBatch(@RequestBody Batch batch) {
		return ResponseEntity.ok(batchService.createBatch(batch));
	}

	@GetMapping("/byCourse/{courseId}")
	public ResponseEntity<List<Batch>> getBatches(@PathVariable int courseId) {
		return ResponseEntity.ok(batchService.getBatchesByCourse(courseId));
	}

	@GetMapping("/all")
	public ResponseEntity<List<Batch>> getAllBatches() {
		return ResponseEntity.ok(batchService.getAllBatches());
	}

	@GetMapping("/{id}")
	public ResponseEntity<Batch> getBatchById(@PathVariable int id) {
		return ResponseEntity.ok(batchService.getBatchById(id));
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<Batch> updateBatch(@PathVariable int id, @RequestBody Batch updatedBatch) {
		return ResponseEntity.ok(batchService.updateBatch(id, updatedBatch));
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteBatch(@PathVariable int id) {
		batchService.deleteBatch(id);
		return ResponseEntity.ok("Batch deleted successfully");
	}
}
