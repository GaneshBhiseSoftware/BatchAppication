package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "users")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String fullname;
	private String password;
	private String role; // "ADMIN" or "USER"
	private String email;
	private String userMobile;
	private String parentMobile;
	private String imageUrl;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUserMobile() {
		return userMobile;
	}

	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}

	public String getParentMobile() {
		return parentMobile;
	}

	public void setParentMobile(String parentMobile) {
		this.parentMobile = parentMobile;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public User(int id, String fullname, String password, String role, String email, String userMobile,
			String parentMobile, String imageUrl) {
		super();
		this.id = id;
		this.fullname = fullname;
		this.password = password;
		this.role = role;
		this.email = email;
		this.userMobile = userMobile;
		this.parentMobile = parentMobile;
		this.imageUrl = imageUrl;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", fullname=" + fullname + ", password=" + password + ", role=" + role + ", email="
				+ email + ", userMobile=" + userMobile + ", parentMobile=" + parentMobile + ", imageUrl=" + imageUrl
				+ "]";
	}

}
