package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Batch;

public interface BatchService {
    Batch createBatch(Batch batch);
    List<Batch> getBatchesByCourse(int courseId);
    List<Batch> getAllBatches();
    Batch getBatchById(int id);
    Batch updateBatch(int id, Batch updatedBatch);
    void deleteBatch(int id);
}
