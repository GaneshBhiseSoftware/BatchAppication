package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Batch {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bid;

	private String title;

	@ManyToOne
	private CourseInfo courseInfo;

	private int createdBy;
	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public CourseInfo getCourseInfo() {
		return courseInfo;
	}

	public void setCourseInfo(CourseInfo courseInfo) {
		this.courseInfo = courseInfo;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	@Override
	public String toString() {
		return "Batch [bid=" + bid + ", title=" + title + ", courseInfo=" + courseInfo + ", createdBy=" + createdBy
				+ "]";
	}

	public Batch() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Batch(int bid, String title, CourseInfo courseInfo, int createdBy) {
		super();
		this.bid = bid;
		this.title = title;
		this.courseInfo = courseInfo;
		this.createdBy = createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

}
