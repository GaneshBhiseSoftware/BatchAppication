const baseUrl = "http://localhost:8080/api";
let currentUser = null;

document.getElementById("loginForm").addEventListener("submit", login);
document.getElementById("registerForm").addEventListener("submit", register);

// Login function
function login(e) {
  e.preventDefault();
  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;

  fetch(`${baseUrl}/users/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password })
  })
    .then(res => res.json())
    .then(user => {
      if (user.id) {
        currentUser = user;
        showDashboard();
      } else {
        alert("Login failed");
      }
    });
}

// Register function
function register(e) {
  e.preventDefault();
  const user = {
    fullname: document.getElementById("regFullname").value,
    email: document.getElementById("regEmail").value,
    password: document.getElementById("regPassword").value,
    userMobile: document.getElementById("regUserMobile").value,
    parentMobile: document.getElementById("regParentMobile").value,
    imageUrl: document.getElementById("regImageUrl").value,
  };

  fetch(`${baseUrl}/users/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(user)
  })
    .then(res => res.json())
    .then(data => {
      alert("Registration successful");
    });
}

// Show dashboard based on role
function showDashboard() {
  document.getElementById("authSection").style.display = "none";
  document.getElementById("dashboardSection").style.display = "block";
  document.getElementById("dashboardTitle").innerText = `Welcome, ${currentUser.fullname}`;

  if (currentUser.role === "ADMIN") {
    document.getElementById("adminPanel").style.display = "block";
    loadCoursesForAdmin();
    loadPendingRequests();
  } else {
    document.getElementById("userPanel").style.display = "block";
    loadCoursesForUser();
    loadUserEnrollments();
    loadInstallments();
  }
}

// Logout
function logout() {
  currentUser = null;
  window.location.reload();
}

// Admin: Create Course
function createCourse() {
  const course = {
    title: document.getElementById("courseTitle").value,
    cprice: parseInt(document.getElementById("coursePrice").value),
    duration: parseInt(document.getElementById("courseDuration").value),
  };

  fetch(`${baseUrl}/courses/create`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(course)
  })
    .then(res => res.json())
    .then(() => {
      alert("Course created");
      loadCoursesForAdmin();
    });
}

// Admin: Load courses in dropdown
function loadCoursesForAdmin() {
  fetch(`${baseUrl}/courses/all`)
    .then(res => res.json())
    .then(courses => {
      const select = document.getElementById("courseSelect");
      select.innerHTML = "";
      courses.forEach(c => {
        const opt = document.createElement("option");
        opt.value = c.cid;
        opt.innerText = c.title;
        select.appendChild(opt);
      });
    });
}

// Admin: Create Batch
function createBatch() {
  const batch = {
    title: document.getElementById("batchTitle").value,
    courseInfo: { cid: parseInt(document.getElementById("courseSelect").value) },
    createdBy: currentUser.id
  };

  fetch(`${baseUrl}/batches/create`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(batch)
  })
    .then(res => res.json())
    .then(() => {
      alert("Batch created");
    });
}

// Admin: Load Pending Enrollments
function loadPendingRequests() {
  fetch(`${baseUrl}/enrollments/pending`)
    .then(res => res.json())
    .then(data => {
      const container = document.getElementById("pendingRequests");
      container.innerHTML = "";
      data.forEach(req => {
        const div = document.createElement("div");
        div.className = "card card-body mb-2";
        div.innerHTML = `
          <b>${req.user.fullname}</b> requested <b>${req.batch.title}</b><br>
          <button class="btn btn-success btn-sm" onclick="approveRequest(${req.id})">Approve</button>
          <button class="btn btn-danger btn-sm" onclick="rejectRequest(${req.id})">Reject</button>
        `;
        container.appendChild(div);
      });
    });
}

function approveRequest(id) {
  fetch(`${baseUrl}/enrollments/approve/${id}`, { method: "PUT" })
    .then(() => {
      alert("Approved");
      loadPendingRequests();
    });
}

function rejectRequest(id) {
  fetch(`${baseUrl}/enrollments/reject/${id}`, { method: "PUT" })
    .then(() => {
      alert("Rejected");
      loadPendingRequests();
    });
}

// User: Load All Courses & Batches
function loadCoursesForUser() {
  fetch(`${baseUrl}/courses/all`)
    .then(res => res.json())
    .then(courses => {
      const courseList = document.getElementById("courseList");
      courseList.innerHTML = "";

      courses.forEach(course => {
        const div = document.createElement("div");
        div.className = "card card-body mb-2";

        fetch(`${baseUrl}/batches/byCourse/${course.cid}`)
          .then(res => res.json())
          .then(batches => {
            let batchHtml = batches.map(b => `
              <div>
                <b>${b.title}</b>
                <button class="btn btn-sm btn-primary ms-2" onclick="enroll(${b.bid})">Enroll</button>
              </div>
            `).join("");

            div.innerHTML = `
              <h5>${course.title}</h5>
              Price: ₹${course.cprice}, Duration: ${course.duration} days
              <div class="mt-2">${batchHtml}</div>
            `;
            courseList.appendChild(div);
          });
      });
    });
}

// User: Enroll
function enroll(batchId) {
  fetch(`${baseUrl}/enrollments/request?userId=${currentUser.id}&batchId=${batchId}`, {
    method: "POST"
  }).then(() => {
    alert("Enrollment requested");
  });
}

// User: View Enrollments
function loadUserEnrollments() {
  fetch(`${baseUrl}/enrollments/user/${currentUser.id}`)
    .then(res => res.json())
    .then(data => {
      const container = document.getElementById("userEnrollments");
      container.innerHTML = "";
      data.forEach(req => {
        const div = document.createElement("div");
        div.className = "card card-body";
        div.innerHTML = `
          Batch: ${req.batch.title}, Status: <b>${req.status}</b>
        `;
        container.appendChild(div);
      });
    });
}

// User: View Installments
function loadInstallments() {
  fetch(`${baseUrl}/installments/user/${currentUser.id}`)
    .then(res => res.json())
    .then(data => {
      const container = document.getElementById("installments");
      container.innerHTML = "";
      data.forEach(inst => {
        const div = document.createElement("div");
        div.className = "card card-body";
        div.innerHTML = `
          ₹${inst.amount} for ${inst.course.title} - Due: ${inst.dueDate}
          <br>Status: <b>${inst.paid ? 'Paid' : 'Pending'}</b>
          ${!inst.paid ? `<button class="btn btn-sm btn-success mt-1" onclick="pay(${inst.id})">Pay Now</button>` : ""}
        `;
        container.appendChild(div);
      });
    });
}

// User: Pay Installment
function pay(id) {
  const today = new Date().toISOString().split("T")[0];
  fetch(`${baseUrl}/installments/pay/${id}?paidDate=${today}`, {
    method: "PUT"
  })
    .then(() => {
      alert("Payment done");
      loadInstallments();
    });
}
